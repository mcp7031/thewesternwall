<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
    {
        /**
     * Run the migrations.
     */
        public function up(): void
        {
            Schema::create('messages', function (Blueprint $table) {
                $table->foreignId('chat_id')->constrained();
                $table->foreignId('sender_chat_id')->nullable();
                $table->unsignedBigInteger('id');
                $table->unsignedBigInteger('message_thread_id')->nullable();
                $table->foreignId('user_id')->constrained();
                $table->timestamp('date')->nullable();
                $table->foreignId('forward_from')->nullable();
                $table->unsignedBigInteger('forward_from_chat')->nullable();
                $table->unsignedBigInteger('forward_from_message_id')->nullable();
                $table->text('forward_signature')->nullable();
                $table->text('forward_sender_name')->nullable();
                $table->timestamp('forward_date')->nullable();
                $table->tinyInteger('is_topic_message')->nullable();
                $table->tinyInteger('is_automatic_forward')->nullable();
                $table->unsignedBigInteger('reply_to_chat')->nullable();
                $table->unsignedBigInteger('reply_to_message')->nullable();
                $table->unsignedBigInteger('via_bot')->nullable();
                $table->timestamp('edit_date')->nullable();
                $table->tinyInteger('has_protected_content')->nullable();
                $table->text('media_group_id')->nullable();
                $table->text('author_signature')->nullable();
                $table->text('text')->nullable();
                $table->text('entities')->nullable();
                $table->text('caption_entities')->nullable();
                $table->text('audio')->nullable();
                $table->text('document')->nullable();
                $table->text('animation')->nullable();
                $table->text('game')->nullable();
                $table->text('photo')->nullable();
                $table->text('sticker')->nullable();
                $table->text('video')->nullable();
                $table->text('voice')->nullable();
                $table->text('video_note')->nullable();
                $table->text('caption')->nullable();
                $table->tinyInteger('has_media_spoiler')->nullable();
                $table->text('contact')->nullable();
                $table->text('location')->nullable();
                $table->text('venue')->nullable();
                $table->text('poll')->nullable();
                $table->text('dice')->nullable();
                $table->text('new_chat_members')->nullable();
                $table->unsignedBigInteger('left_chat_member')->nullable();
                $table->string('new_chat_title')->nullable();
                $table->text('new_chat_photo')->nullable();
                $table->tinyInteger('delete_chat_photo')->nullable();
                $table->tinyInteger('group_chat_created')->nullable();
                $table->tinyInteger('supergroup_chat_created')->nullable();
                $table->tinyInteger('channel_chat_created')->nullable();
                $table->text('message_auto_delete_timer_changed')->nullable();
                $table->unsignedBigInteger('migrate_to_chat_id')->nullable();
                $table->unsignedBigInteger('migrate_from_chat_id')->nullable();
                $table->text('pinned_message')->nullable();
                $table->text('invoice')->nullable();
                $table->text('successful_payment')->nullable();
                $table->text('user_shared')->nullable();
                $table->text('chat_shared')->nullable();
                $table->text('connected_website')->nullable();
                $table->text('write_access_allowed')->nullable();
                $table->text('passport_data')->nullable();
                $table->text('proximity_alert_triggered')->nullable();
                $table->text('forum_topic_created')->nullable();
                $table->text('forum_topic_edited')->nullable();
                $table->text('forum_topic_closed')->nullable();
                $table->text('forum_topic_reopened')->nullable();
                $table->text('general_forum_topic_hidden')->nullable();
                $table->text('general_forum_topic_unhidden')->nullable();
                $table->text('video_chat_scheduled')->nullable();
                $table->text('video_chat_started')->nullable();
                $table->text('video_chat_ended')->nullable();
                $table->text('video_chat_participants_invited')->nullable();
                $table->text('web_app_data')->nullable();
                $table->text('reply_markup')->nullable();

                $table->primary(['chat_id', 'id']);
                $table->index('user_id');
                $table->index('forward_from');
                $table->index('forward_from_chat');
                $table->index('reply_to_chat');
                $table->index('reply_to_message');
                $table->index('via_bot');
                $table->index('left_chat_member');
                $table->index('migrate_from_chat_id');
                $table->index('migrate_to_chat_id');

                $table->foreign('sender_chat_id')->references('id')->on('users');
                $table->foreign('forward_from')->references('id')->on('users');
                $table->foreign('forward_from_chat')->references('id')->on('chats');
                $table->foreign('reply_to_chat', 'reply_to_message')->references('chat_id', 'id')->on('messages');
                $table->foreign('via_bot')->references('id')->on('users');
                $table->foreign('left_chat_member')->references('id')->on('users');
                $table->timestamps();
            });
        }
/*
            CREATE TABLE IF NOT EXISTS `message` (
                `chat_id` bigint COMMENT 'Unique chat identifier',
                `sender_chat_id` bigint COMMENT 'Sender of the message, sent on behalf of a chat',
                `id` bigint UNSIGNED COMMENT 'Unique message identifier',
                `message_thread_id` bigint(20) DEFAULT NULL COMMENT 'Unique identifier of a message thread to which the message belongs; for supergroups only',
                `user_id` bigint NULL COMMENT 'Unique user identifier',
                `date` timestamp NULL DEFAULT NULL COMMENT 'Date the message was sent in timestamp format',
                `forward_from` bigint NULL DEFAULT NULL COMMENT 'Unique user identifier, sender of the original message',
                `forward_from_chat` bigint NULL DEFAULT NULL COMMENT 'Unique chat identifier, chat the original message belongs to',
                `forward_from_message_id` bigint NULL DEFAULT NULL COMMENT 'Unique chat identifier of the original message in the channel',
                `forward_signature` TEXT NULL DEFAULT NULL COMMENT 'For messages forwarded from channels, signature of the post author if present',
                `forward_sender_name` TEXT NULL DEFAULT NULL COMMENT 'Sender''s name for messages forwarded from users who disallow adding a link to their account in forwarded messages',
                `forward_date` timestamp NULL DEFAULT NULL COMMENT 'date the original message was sent in timestamp format',
                `is_topic_message` tinyint(1) DEFAULT 0 COMMENT 'True, if the message is sent to a forum topic',
                `is_automatic_forward` tinyint(1) DEFAULT 0 COMMENT 'True, if the message is a channel post that was automatically forwarded to the connected discussion group',
                `reply_to_chat` bigint NULL DEFAULT NULL COMMENT 'Unique chat identifier',
                `reply_to_message` bigint UNSIGNED DEFAULT NULL COMMENT 'Message that this message is reply to',
                `via_bot` bigint NULL DEFAULT NULL COMMENT 'Optional. Bot through which the message was sent',
                `edit_date` timestamp NULL DEFAULT NULL COMMENT 'Date the message was last edited in Unix time',
                `has_protected_content` tinyint(1) DEFAULT 0 COMMENT 'True, if the message can''t be forwarded',
                `media_group_id` TEXT COMMENT 'The unique identifier of a media message group this message belongs to',
                `author_signature` TEXT COMMENT 'Signature of the post author for messages in channels',
                `text` TEXT COMMENT 'For text messages, the actual UTF-8 text of the message max message length 4096 char utf8mb4',
                `entities` TEXT COMMENT 'For text messages, special entities like usernames, URLs, bot commands, etc. that appear in the text',
                `caption_entities` TEXT COMMENT 'For messages with a caption, special entities like usernames, URLs, bot commands, etc. that appear in the caption',
                `audio` TEXT COMMENT 'Audio object. Message is an audio file, information about the file',
                `document` TEXT COMMENT 'Document object. Message is a general file, information about the file',
                `animation` TEXT COMMENT 'Message is an animation, information about the animation',
                `game` TEXT COMMENT 'Game object. Message is a game, information about the game',
                `photo` TEXT COMMENT 'Array of PhotoSize objects. Message is a photo, available sizes of the photo',
                `sticker` TEXT COMMENT 'Sticker object. Message is a sticker, information about the sticker',
                `video` TEXT COMMENT 'Video object. Message is a video, information about the video',
                `voice` TEXT COMMENT 'Voice Object. Message is a Voice, information about the Voice',
                `video_note` TEXT COMMENT 'VoiceNote Object. Message is a Video Note, information about the Video Note',
                `caption` TEXT COMMENT  'For message with caption, the actual UTF-8 text of the caption',
                `has_media_spoiler` tinyint(1) DEFAULT 0 COMMENT 'True, if the message media is covered by a spoiler animation',
                `contact` TEXT COMMENT 'Contact object. Message is a shared contact, information about the contact',
                `location` TEXT COMMENT 'Location object. Message is a shared location, information about the location',
                `venue` TEXT COMMENT 'Venue object. Message is a Venue, information about the Venue',
                `poll` TEXT COMMENT 'Poll object. Message is a native poll, information about the poll',
                `dice` TEXT COMMENT 'Message is a dice with random value from 1 to 6',
                `new_chat_members` TEXT COMMENT 'List of unique user identifiers, new member(s) were added to the group, information about them (one of these members may be the bot itself)',
                `left_chat_member` bigint NULL DEFAULT NULL COMMENT 'Unique user identifier, a member was removed from the group, information about them (this member may be the bot itself)',
                `new_chat_title` CHAR(255) DEFAULT NULL COMMENT 'A chat title was changed to this value',
                `new_chat_photo` TEXT COMMENT 'Array of PhotoSize objects. A chat photo was change to this value',
                `delete_chat_photo` tinyint(1) DEFAULT 0 COMMENT 'Informs that the chat photo was deleted',
                `group_chat_created` tinyint(1) DEFAULT 0 COMMENT 'Informs that the group has been created',
                `tinyIntegersupergroup_chat_created` tinyint(1) DEFAULT 0 COMMENT 'Informs that the supergroup has been created',
                `channel_chat_created` tinyint(1) DEFAULT 0 COMMENT 'Informs that the channel chat has been created',
                `message_auto_delete_timer_changed` TEXT COMMENT 'MessageAutoDeleteTimerChanged object. Message is a service message: auto-delete timer settings changed in the chat',
                `migrate_to_chat_id` bigint NULL DEFAULT NULL COMMENT 'Migrate to chat identifier. The group has been migrated to a supergroup with the specified identifier',
                `migrate_from_chat_id` bigint NULL DEFAULT NULL COMMENT 'Migrate from chat identifier. The supergroup has been migrated from a group with the specified identifier',
                `pinned_message` TEXT NULL COMMENT 'Message object. Specified message was pinned',
                `invoice` TEXT NULL COMMENT 'Message is an invoice for a payment, information about the invoice',
                `successful_payment` TEXT NULL COMMENT 'Message is a service message about a successful payment, information about the payment',
                `user_shared` TEXT NULL COMMENT 'Optional. Service message: a user was shared with the bot',
                `chat_shared` TEXT NULL COMMENT 'Optional. Service message: a chat was shared with the bot',
                `connected_website` TEXT NULL COMMENT 'The domain name of the website on which the user has logged in.',
                `write_access_allowed` TEXT DEFAULT NULL COMMENT 'Service message: the user allowed the bot added to the attachment menu to write messages',
                `passport_data` TEXT NULL COMMENT 'Telegram Passport data',
                `proximity_alert_triggered` TEXT NULL COMMENT 'Service message. A user in the chat triggered another user''s proximity alert while sharing Live Location.',
                    `forum_topic_created` TEXT DEFAULT NULL COMMENT 'Service message: forum topic created',
                    `forum_topic_edited` TEXT DEFAULT NULL COMMENT 'Service message: forum topic edited',
                    `forum_topic_closed` TEXT DEFAULT NULL COMMENT 'Service message: forum topic closed',
                    `forum_topic_reopened` TEXT DEFAULT NULL COMMENT 'Service message: forum topic reopened',
                    `general_forum_topic_hidden` TEXT DEFAULT NULL COMMENT 'Service message: the General forum topic hidden',
                    `general_forum_topic_unhidden` TEXT DEFAULT NULL COMMENT 'Service message: the General forum topic unhidden',
                    `video_chat_scheduled` TEXT COMMENT 'Service message: video chat scheduled',
                    `video_chat_started` TEXT COMMENT 'Service message: video chat started',
                    `video_chat_ended` TEXT COMMENT 'Service message: video chat ended',
                    `video_chat_participants_invited` TEXT COMMENT 'Service message: new participants invited to a video chat',
                    `web_app_data` TEXT COMMENT 'Service message: data sent by a Web App',
                    `reply_markup` TEXT NULL COMMENT 'Inline keyboard attached to the message',

                    PRIMARY KEY (`chat_id`, `id`),
                    KEY `user_id` (`user_id`),
                    KEY `forward_from` (`forward_from`),
                    KEY `forward_from_chat` (`forward_from_chat`),
                    KEY `reply_to_chat` (`reply_to_chat`),
                    KEY `reply_to_message` (`reply_to_message`),
                    KEY `via_bot` (`via_bot`),
                    KEY `left_chat_member` (`left_chat_member`),
                    KEY `migrate_from_chat_id` (`migrate_from_chat_id`),
                    KEY `migrate_to_chat_id` (`migrate_to_chat_id`),

                    FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
                    FOREIGN KEY (`chat_id`) REFERENCES `chat` (`id`),
                    FOREIGN KEY (`forward_from`) REFERENCES `user` (`id`),
                    FOREIGN KEY (`forward_from_chat`) REFERENCES `chat` (`id`),
                    FOREIGN KEY (`reply_to_chat`, `reply_to_message`) REFERENCES `message` (`chat_id`, `id`),
                    FOREIGN KEY (`via_bot`) REFERENCES `user` (`id`),
                    FOREIGN KEY (`left_chat_member`) REFERENCES `user` (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
                */
                /**
     * Reverse the migrations.
     */
                public function down(): void
                {
                Schema::dropIfExists('messages');
        }
    };
