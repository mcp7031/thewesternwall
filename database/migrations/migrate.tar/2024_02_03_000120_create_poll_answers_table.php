<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
    {
        /**
     * Run the migrations.
     */
        public function up(): void
        {
            Schema::create('poll_answers', function (Blueprint $table) {
                $table->foreignId('poll_id')->constrained();
                $table->foreignId('user_id')->constrained();
                $table->text('option_ids');
                $table->timestamps();

                $table->primary('poll_id', 'user_id');
            });
        }
        /*
CREATE TABLE IF NOT EXISTS `poll_answer` (
  `poll_id` bigint UNSIGNED COMMENT 'Unique poll identifier',
  `user_id` bigint NOT NULL COMMENT 'The user, who changed the answer to the poll',
  `option_ids` text NOT NULL COMMENT '0-based identifiers of answer options, chosen by the user. May be empty if the user retracted their vote.',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',

  PRIMARY KEY (`poll_id`, `user_id`),
  FOREIGN KEY (`poll_id`) REFERENCES `poll` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
*/
        /**
     * Reverse the migrations.
     */
        public function down(): void
        {
            Schema::dropIfExists('poll_answers');
        }
    };
